class BooksController < ApplicationController
    def index
  @books = Book.all

  # Check if minimum and maximum prices were provided in the search form
  if params[:min_price].present? && params[:max_price].present?
    @books = @books.where(price: params[:min_price]..params[:max_price])
  end
end

    def show
        find_book
    end

    def new
        @book = Book.new
    end

    def create
        @book = Book.new(book_params)

        if @book.save
            redirect_to '/books',notice: 'Book Created!'
        else
            render :new
        end
    end

    def edit
        find_book
    end

    def update
        find_book
        if @book.update(book_params)
            redirect_to '/books',notice: 'Book Updated!'
        else
            render :edit
        end
    end

    def destroy
        find_book
        @book.destroy
        redirect_to '/books', notice: 'This book Deleted!'
    end

    private
    def book_params
        params.require(:book).permit(:title,:content,:price)
    end

    def find_book
        @book = Book.find_by(id: params[:id])
    end
end
